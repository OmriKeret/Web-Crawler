import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import Helpers.InReqHttpParser;
import Helpers.OutReqHttpParser;
import Helpers.HttpRequestFormater;
import Threads.syncTaskQueue;
import config.configService;

public class Downloader implements Runnable {
	final static String CRLF = "\r\n";
	final static String HTTP_VERSION = "1.1";
	private syncTaskQueue<String> urlQueue;
	private syncTaskQueue<String> documentQueue;
	HttpRequestFormater requestParse;
	private configService conf;
	Pattern acceptedImagePattern, acceptedVideoPattern, acceptedDocuments;
	/**
	 *  Constructor.
	 */
	Downloader(syncTaskQueue<String> _urlQueue, syncTaskQueue<String> _documentQueue) {
		urlQueue = _urlQueue;
		documentQueue = _documentQueue;	
		buildPatterns();

	}

	private void buildPatterns() {
		StringBuilder imagePattern = new StringBuilder();
		for (String str )
		acceptedImagePattern = Pattern.compile(".*\\.(.+?$)");
	}

	@Override
	public void run() {
		try {
			String currentUrl;

			// Do forever:
			// 1. Take a link to download
			// 2. Check if should download link
			// 3. Enqueue downloaded document.

			while (true) {

				currentUrl = urlQueue.remove();
				Socket clientSocket = null;
				try {
					
					// Initiate TCP connetcion.
					clientSocket = new Socket(currentUrl, 80);
					DataOutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream()); 
					InputStream inFromServer = clientSocket.getInputStream();
					
					if (isHtml()) {
						// Download document.

						// Helper function that Parse the desired request.
						String request = requestParse.getGetRequest(currentUrl, HTTP_VERSION);

						// Write the request.
						outToServer.writeBytes(request);  

						// Now we should receive the HTML file.
						OutReqHttpParser parser= new OutReqHttpParser(inFromServer);

						parser.parseResponse();
						String body = parser.getBody();
						if (body != null) {
							documentQueue.insert(body);
						}
						
						// Update statistics.
						
						clientSocket.close();
						
					} else {
						// Do an head request
						
						
					}
				} catch (Exception e) {
					// Error while parsing request.
					System.out.println("Error while downlding, stoped downloading");
					try {
						clientSocket.close();
					} catch (IOException e1) {

					}

				}


			}

		} catch (InterruptedException e) {

			System.out.println("Error accured while downloading content.");
		}	
	}

	private boolean isHtml() {
		// TODO Auto-generated method stub
		return false;
	}





}
