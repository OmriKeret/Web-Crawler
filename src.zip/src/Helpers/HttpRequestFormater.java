package Helpers;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class HttpRequestFormater {
	final static String CRLF = "\r\n";
	private Pattern urlPattern;
	private Matcher urlMatcher;
	
	public HttpRequestFormater() {
		urlPattern = Pattern.compile(".*((http:[//].+?)| (www.+?))[/]+(.*)");
	}
	
	/**
	 * Functino recive filePath (url) and http version and returns a string of the required request.
	 * @param filePath
	 * @param version
	 * @return
	 */
	public String getGetRequest(String filePath, String version) {
//		GET / HTTP/1.0
//		Host: www.ynet.co.il
		String result = "GET " + getFileRoute(filePath) + "/" + version + CRLF;
		result = result + "Host: " + getHost(filePath) + CRLF + CRLF;
		return result;
	}
    
	/**
	 * Helper function to recive host from url.
	 * @param filePath
	 * @return
	 */
	private String getHost(String filePath) {
		urlMatcher = urlPattern.matcher(filePath);
		String result = null;
		if (urlMatcher.find()) {
			result = urlMatcher.group(1);
		}
		return result;
	}

	/**
	 * Helper function to recive host from url.
	 * @param filePath
	 * @return
	 */
	private String getFileRoute(String filePath) {
		urlMatcher = urlPattern.matcher(filePath);
		String result = null;
		if (urlMatcher.find()) {
			result = urlMatcher.group(2);
		}
		return result;
	}
}
