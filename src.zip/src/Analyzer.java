
public class Analyzer implements Runnable {

	@Override
	public void run() {
		// Do forever:
		// 1. Take a link to download
		// 2. Check if should download link
		// 3. Enqueue downloaded document.
		
	}

}
